#!/bin/sh
set -e
set -x

echo "Creating dev environment in ./venv..."

python3 -m venv venv
. venv/bin/activate
python3 -m pip install -U pip setuptools
python3 -m pip install -r requirements.txt

echo ""
echo "  * Created virtualenv environment in ./venv."
echo "  * Installed all dependencies into the virtualenv."
echo "  * You can now activate the $(python3 --version) virtualenv with this command: \`. venv/bin/activate\`"
