
def request(flow):
    flow.request.headers["myheader"] = "value"
