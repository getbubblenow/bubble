from mitmproxy.script import concurrent


@concurrent
def load(v):
    pass
