foo = 42
