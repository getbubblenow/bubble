def load(_):
    raise ValueError()
