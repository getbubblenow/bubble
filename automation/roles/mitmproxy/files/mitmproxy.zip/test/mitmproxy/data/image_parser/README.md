# Sources of the images used

## PNG

`aspect.png` - http://pngimg.com/upload/water_PNG3290.png
All other PNGs are from the [PNGTestSuite](http://www.schaik.com/pngsuite/)

# GIF

All the GIFs are from the Pillow repository [here](https://github.com/python-pillow/Pillow/tree/master/Tests/images)

# JPEG

`app1.jpeg` - https://commons.wikimedia.org/wiki/File:PT05_ubt.jpeg
`all.jpeg` - https://commons.wikimedia.org/wiki/Category:Dante's_Inferno#/media/File:Bartolomeo_Di_Fruosino_-_Inferno,_from_the_Divine_Comedy_by_Dante_(Folio_1v)_-_WGA01339.jpg
`comment.jpg` has been taken from [here](https://commons.wikimedia.org/wiki/File:JPEG_example_image.jpg) and has a comment added locally
All other JPEGs are from the Pillow repository [here](https://github.com/python-pillow/Pillow/tree/master/Tests/images)
