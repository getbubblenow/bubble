"""
This file is intended to have syntax errors for test purposes
"""

impotr recorder # Intended Syntax Error

addons = [recorder.Recorder("e")]
