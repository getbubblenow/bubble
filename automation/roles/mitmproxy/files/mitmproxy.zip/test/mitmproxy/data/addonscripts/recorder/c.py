import recorder

addons = [recorder.Recorder("c")]
