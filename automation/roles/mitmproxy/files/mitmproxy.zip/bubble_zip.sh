#!/bin/bash

if [[ -z "${BUBBLE_HOME}" ]] ; then
    BUBBLE_HOME=${1:?no BUBBLE_HOME provided}
fi

MITM_DIR="$(cd "$(dirname "${0}")" && pwd)"
MITM="$(basename "${MITM_DIR}")"

cd ${MITM_DIR} && \
git archive --format=zip -o ${BUBBLE_HOME}/automation/roles/mitmproxy/files/mitmproxy.zip bubble
