# Android client setup

## Installation via profiles

1. [Install the WireGuard VPN Client](https://play.google.com/store/apps/details?id=com.wireguard.android).
2. Open QR code `configs/<ip_address>/wireguard/<username>.png` and scan it in the WireGuard app
